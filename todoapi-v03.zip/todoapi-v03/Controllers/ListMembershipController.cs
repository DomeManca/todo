﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TodoApi.Models;

namespace ListMembershipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ListMembershipController : ControllerBase
    {
        private readonly ListMembershipContext _context;
        private readonly UserContext _contextUser;

        public ListMembershipController(ListMembershipContext context, UserContext contextUser)
        {
            _context = context;
            _contextUser = contextUser;
        }

        // GET: ListMembership
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ListMembership>>> GetListMemberships()
        {
            return await _context.ListsMemberships
                .Include(lm => lm.User) // Include the related User entity
                .Include(lm => lm.List) // Include the related List entity
                .ToListAsync();
        }

        // GET: ListMembership/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ListMembership>> GetListMembership(int id)
        {
            var listMembership = await _context.ListsMemberships
                .Include(lm => lm.User) // Include the related User entity
                .Include(lm => lm.List) // Include the related List entity
                .FirstOrDefaultAsync(lm => lm.Id == id);

            if (listMembership == null)
            {
                return NotFound();
            }

            return listMembership;
        }

        // GET: ListMembership/{id}/User
        [HttpGet("{id}/User")]
        public async Task<ActionResult<User>> GetListMembershipUser(int id)
        {
            var listMembership = await _context.ListsMemberships
                .Include(lm => lm.User) // Ensure the User is included
                .Include(lm => lm.List) // Ensure the List is included
                .FirstOrDefaultAsync(lm => lm.Id == id);

            if (listMembership == null)
            {
                return NotFound();
            }

            return listMembership.User;
        }

        // GET: ListMembership/{id}/List
        [HttpGet("{id}/List")]
        public async Task<ActionResult<List>> GetListMembershipList(int id)
        {
            var listMembership = await _context.ListsMemberships
                .Include(lm => lm.User) // Ensure the User is included
                .Include(lm => lm.List) // Ensure the List is included
                .FirstOrDefaultAsync(lm => lm.Id == id);

            if (listMembership == null)
            {
                return NotFound();
            }

            return listMembership.List;
        }

        // POST: ListMembership
        [HttpPost]
        public async Task<ActionResult<ListMembership>> PostListMembership(ListMembership item)
        {
            _context.ListsMemberships.Add(item);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetListMembership), new { id = item.Id }, item);
        }

        // PUT: ListMembership/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutListMembership(int id, ListMembership item)
        {
            if (id != item.Id)
            {
                return BadRequest();
            }

            _context.Entry(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: ListMembership/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteListMembership(int id)
        {
            var listMembership = await _context.ListsMemberships.FindAsync(id);

            if (listMembership == null)
            {
                return NotFound();
            }

            _context.ListsMemberships.Remove(listMembership);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
