﻿using Microsoft.EntityFrameworkCore;

namespace TodoApi.Models
{
    public class GroupContext : DbContext
    {
        public GroupContext(DbContextOptions<TodoContext> options)
            : base(options)
        {
        }

        public DbSet<Group> Groups { get; set; }
    }
}